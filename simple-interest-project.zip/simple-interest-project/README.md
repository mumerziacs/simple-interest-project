# Simple Interest Project


This is a beginner project demonstrating a simple interest calculator using Bash scripting.


## Files included:
- LICENSE (Apache 2.0)
- README.md
- CODE_OF_CONDUCT.md
- CONTRIBUTING.md
- simple-interest.sh


## How to use
1. Open terminal.
2. Run `./simple-interest.sh`.
3. Enter Principal, Rate, and Time when prompted.
4. The script will calculate and display the Simple Interest.


This project is for learning purposes and GitHub submission practice.